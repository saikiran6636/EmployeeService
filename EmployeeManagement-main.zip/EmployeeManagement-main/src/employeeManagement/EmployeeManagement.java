package employeeManagement;

import java.sql.*;
import java.util.*;

public class EmployeeManagement {

    static final String URL = "jdbc:mysql://localhost:3306/employee_db";
    static final String USER = "root";
    static final String PASSWORD = "Admin123";

    static Connection getConnection() throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        boolean z = true;

        do {
            System.out.println("\n1. Create Employee");
            System.out.println("2. Display Employees");
            System.out.println("3. Raise Salary");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");

            byte ch = sc.nextByte();
            sc.nextLine();

            switch (ch) {

                case 1:

                    String name;
                    while (true) {
                        System.out.println("Enter Name (must contain up to two spaces):");
                        name = sc.nextLine();

                        if (name.split(" ").length <= 3) {
                            break;
                        } else {
                            System.out.println("Name should contain only up to two spaces.");
                        }
                    }

                    byte age;
                    while (true) {
                        System.out.print("Enter Age: ");
                        age = sc.nextByte();
                        sc.nextLine();

                        if (age >= 20 && age < 60)
                            break;
                        else
                            System.out.println("Age must be between 20 and 59.");
                    }

                    String designation;
                    while (true) {
                        System.out.print("Enter Designation (Manager / Programmer / Tester): ");
                        designation = sc.nextLine();

                        if (designation.equals("Manager") ||
                            designation.equals("Programmer") ||
                            designation.equals("Tester"))
                            break;
                        else
                            System.out.println("Invalid Designation.");
                    }

                    double salary =
                            designation.equals("Manager") ? 25000 :
                            designation.equals("Programmer") ? 20000 : 15000;

                    try (Connection con = getConnection()) {

                        String sql = "INSERT INTO employee(name, age, designation, salary) VALUES (?, ?, ?, ?)";
                        PreparedStatement ps = con.prepareStatement(sql);

                        ps.setString(1, name);
                        ps.setInt(2, age);
                        ps.setString(3, designation);
                        ps.setDouble(4, salary);

                        ps.executeUpdate();
                        System.out.println("Employee Inserted Successfully.");

                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    break;

                case 2:

                    try (Connection con = getConnection()) {

                        Statement st = con.createStatement();
                        ResultSet rs = st.executeQuery("SELECT * FROM employee");

                        boolean found = false;

                        while (rs.next()) {
                            found = true;
                            System.out.println("\nEmployee ID: " + rs.getInt("id"));
                            System.out.println("Name: " + rs.getString("name"));
                            System.out.println("Age: " + rs.getInt("age"));
                            System.out.println("Designation: " + rs.getString("designation"));
                            System.out.println("Salary: " + rs.getDouble("salary"));
                            System.out.println("-----------------------------");
                        }

                        if (!found) {
                            System.out.println("No Employees Found.");
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    break;

                case 3:

                    System.out.print("Enter Employee Name: ");
                    String empName = sc.nextLine();

                    System.out.print("Enter Hike Percentage (1 to 10): ");
                    int percent = sc.nextInt();
                    sc.nextLine();

                    if (percent < 1 || percent > 10) {
                        System.out.println("Hike must be between 1 and 10 percent.");
                        break;
                    }

                    try (Connection con = getConnection()) {

                        String select = "SELECT salary FROM employee WHERE name=?";
                        PreparedStatement ps1 = con.prepareStatement(select);
                        ps1.setString(1, empName);
                        ResultSet rs = ps1.executeQuery();

                        if (rs.next()) {
                            double oldSalary = rs.getDouble(1);
                            double newSalary = oldSalary + (oldSalary * percent / 100);

                            String update = "UPDATE employee SET salary=? WHERE name=?";
                            PreparedStatement ps2 = con.prepareStatement(update);
                            ps2.setDouble(1, newSalary);
                            ps2.setString(2, empName);

                            ps2.executeUpdate();
                            System.out.println("Salary Updated Successfully.");
                        } else {
                            System.out.println("Employee Not Found.");
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    break;

                case 4:
                    System.out.println("Thank you for using the application.");
                    z = false;
                    break;

                default:
                    System.out.println("Enter a number between 1 and 4 only.");
            }

        } while (z);
    }
}
